# Music_RBM
Use TensorFlow to generate short sequences of music with an RBM

To train the model and create music, simply clone this directory and run

```
python rbm_chords.py
```
